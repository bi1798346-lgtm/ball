const express = require('express');
const axios = require('axios');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

// ==================== CAPTCHA API ====================
app.get('/api/captcha', async (req, res) => {
    try {
        // Ambil dari necaptcha
        const response = await axios.get('https://necaptcha.jphgpt.f5.si/', {
            timeout: 10000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });

        const token = response.data.trim();
        
        if (token && token.length > 10) {
            res.json({
                success: true,
                token: token
            });
        } else {
            throw new Error('Invalid token format');
        }
    } catch (error) {
        console.error('Captcha fetch error:', error.message);
        res.status(500).json({
            success: false,
            error: 'Gagal mengambil captcha token'
        });
    }
});

// ==================== CHECK ACCOUNT API ====================
app.post('/api/check', async (req, res) => {
    const { email, password, captcha, abck } = req.body;

    if (!email || !password || !captcha) {
        return res.status(400).json({
            success: false,
            error: 'Email, password, dan captcha required'
        });
    }

    try {
        // Hash password dengan MD5
        const md5Password = require('crypto')
            .createHash('md5')
            .update(password)
            .digest('hex');

        // Buat signature
        const params = {
            account: email,
            md5pwd: md5Password,
            game_token: "",
            recaptcha_token: "",
            e_captcha: captcha,
            country: ""
        };

        const sign = makeSign(params);

        // Request ke API MLBB
        const loginResponse = await axios.post('https://accountmtapi.mobilelegends.com', {
            op: "login",
            sign: sign,
            params: params,
            lang: "en"
        }, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Content-Type': 'application/json',
                'Cookie': abck ? `_abck=${abck}` : ''
            },
            timeout: 15000
        });

        const loginData = loginResponse.data;

        // Cek response code
        if (loginData.code !== 0) {
            return res.json({
                success: false,
                error: loginData.message || 'Login failed'
            });
        }

        // Ambil session dan GUID
        const sessionToken = loginData.data?.session;
        const guid = loginData.data?.guid;

        if (!sessionToken) {
            return res.json({
                success: false,
                error: 'No session token'
            });
        }

        // Ambil JWT token
        const jwtResponse = await axios.post('https://api.mobilelegends.com/tools/deleteaccount/getToken', {
            id: guid,
            token: sessionToken,
            type: "mt_And"
        }, {
            headers: {
                'Authorization': sessionToken
            },
            timeout: 10000
        });

        const jwt = jwtResponse.data?.data?.jwt;

        if (!jwt) {
            return res.json({
                success: false,
                error: 'No JWT token'
            });
        }

        // Ambil info akun
        const [infoRes, bindRes, banRes] = await Promise.allSettled([
            axios.post('https://sg-api.mobilelegends.com/base/getBaseInfo', {}, {
                headers: { 'Authorization': `Bearer ${jwt}` },
                timeout: 8000
            }),
            axios.post('https://api.mobilelegends.com/tools/deleteaccount/getCancelAccountInfo', {}, {
                headers: { 'Authorization': `Bearer ${jwt}` },
                timeout: 8000
            }),
            axios.post('https://api.mobilelegends.com/tools/selfservice/punishList', {
                lang: "en"
            }, {
                headers: { 'Authorization': `Bearer ${jwt}` },
                timeout: 8000
            })
        ]);

        // Parse results
        const info = infoRes.status === 'fulfilled' ? infoRes.value.data?.data || {} : {};
        const bind = bindRes.status === 'fulfilled' ? bindRes.value.data?.data || {} : {};
        const ban = banRes.status === 'fulfilled' ? banRes.value.data?.data || [] : [];

        // Format response
        res.json({
            success: true,
            banned: ban.length > 0,
            banReason: ban[0]?.reason || null,
            nickname: info.name || 'Unknown',
            level: info.level || 'N/A',
            roleId: info.roleId || 'N/A',
            zoneId: info.zoneId || 'N/A',
            rank: getRankName(info.rank_level),
            highestRank: getRankName(info.history_rank_level),
            bindings: parseBindings(bind),
            creationDate: 'N/A' // Bisa ditambah API creation date
        });

    } catch (error) {
        console.error('Check error:', error.message);
        res.json({
            success: false,
            error: error.message || 'Unknown error'
        });
    }
});

// ==================== HELPER FUNCTIONS ====================
function makeSign(params) {
    const sorted = Object.keys(params)
        .sort()
        .map(key => `${key}=${params[key]}`)
        .join('&') + '&op=login';
    
    return require('crypto')
        .createHash('md5')
        .update(sorted)
        .digest('hex');
}

function getRankName(level) {
    const ranks = [
        { min: 0, max: 4, name: "Warrior III" },
        { min: 5, max: 9, name: "Warrior II" },
        { min: 10, max: 14, name: "Warrior I" },
        { min: 15, max: 19, name: "Elite IV" },
        { min: 20, max: 24, name: "Elite III" },
        { min: 25, max: 29, name: "Elite II" },
        { min: 30, max: 34, name: "Elite I" },
        { min: 35, max: 39, name: "Master IV" },
        { min: 40, max: 44, name: "Master III" },
        { min: 45, max: 49, name: "Master II" },
        { min: 50, max: 54, name: "Master I" },
        { min: 55, max: 59, name: "Grandmaster IV" },
        { min: 60, max: 64, name: "Grandmaster III" },
        { min: 65, max: 69, name: "Grandmaster II" },
        { min: 70, max: 74, name: "Grandmaster I" },
        { min: 75, max: 79, name: "Epic IV" },
        { min: 80, max: 84, name: "Epic III" },
        { min: 85, max: 89, name: "Epic II" },
        { min: 90, max: 94, name: "Epic I" },
        { min: 95, max: 99, name: "Legend IV" },
        { min: 100, max: 104, name: "Legend III" },
        { min: 105, max: 109, name: "Legend II" },
        { min: 110, max: 114, name: "Legend I" },
        { min: 115, max: 136, name: "Mythic" },
        { min: 137, max: 999, name: "Mythical Glory" }
    ];

    const rank = ranks.find(r => level >= r.min && level <= r.max);
    return rank ? rank.name : "Unknown";
}

function parseBindings(bindData) {
    const binds = [];
    if (bindData.is_fb_bind) binds.push('Facebook');
    if (bindData.is_google_bind) binds.push('Google');
    if (bindData.is_apple_bind) binds.push('Apple');
    if (bindData.is_mt_bind) binds.push('Moonton');
    if (bindData.is_twitter_bind) binds.push('Twitter');
    if (bindData.is_vk_bind) binds.push('VK');
    if (bindData.is_tiktok_bind) binds.push('TikTok');
    
    return binds.length > 0 ? binds.join(' + ') : 'No Bind';
}

// ==================== START SERVER ====================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Backend running on port ${PORT}`);
});