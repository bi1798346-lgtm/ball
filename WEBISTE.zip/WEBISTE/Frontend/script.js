* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
}

body {
    background: linear-gradient(145deg, #1a0b2e 0%, #2d154d 100%);
    min-height: 100vh;
    padding: 20px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.container {
    max-width: 1200px;
    width: 100%;
}

/* Header */
.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    flex-wrap: wrap;
    gap: 20px;
}

.logo h1 {
    font-size: 2.5rem;
    font-weight: 800;
    background: linear-gradient(145deg, #f5d6ff, #c28eff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    display: inline;
    filter: drop-shadow(0 0 15px #b259ff);
}

.badge {
    background: #8a4ed4;
    color: white;
    padding: 8px 18px;
    border-radius: 40px;
    font-weight: 600;
    margin-left: 15px;
    border: 2px solid #dbb0ff;
    box-shadow: 0 5px 0 #562d92;
}

.credit {
    background: #2f1952;
    color: #e9cbff;
    padding: 12px 28px;
    border-radius: 50px;
    border: 2px solid #b87aff;
    font-weight: 600;
    box-shadow: 0 5px 0 #582f9b;
}

/* Cards */
.card {
    background: rgba(36, 18, 59, 0.9);
    backdrop-filter: blur(10px);
    border: 2px solid #b87aff;
    border-radius: 50px;
    padding: 30px;
    margin-bottom: 25px;
    box-shadow: 0 15px 0 #562d92, 0 20px 40px rgba(0,0,0,0.5);
}

.card-title {
    font-size: 1.6rem;
    color: #f0d2ff;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    border-bottom: 3px dashed #b87aff;
    padding-bottom: 15px;
}

.card-title i {
    font-size: 2rem;
    color: #d09eff;
}

/* Captcha */
.captcha-box {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.captcha-box input {
    flex: 3;
    min-width: 300px;
    background: #1b0e2b;
    border: 2px solid #b87aff;
    border-radius: 50px;
    padding: 18px 25px;
    color: white;
    font-size: 1rem;
    outline: none;
}

.captcha-box input:focus {
    border-color: #eab2ff;
    box-shadow: 0 0 30px #c47aff;
}

.btn {
    border: none;
    background: #2f1b4f;
    border: 2px solid #b87aff;
    border-radius: 50px;
    padding: 16px 32px;
    font-weight: 700;
    color: white;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    transition: 0.2s;
    font-size: 1rem;
}

.btn.primary {
    background: linear-gradient(145deg, #aa55ff, #7a3dd6);
    box-shadow: 0 7px 0 #4d1f8b;
    border: 1px solid #e2b5ff;
}

.btn.primary:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 0 #4d1f8b;
}

.token-status {
    margin-top: 20px;
    background: #22133b;
    border-radius: 50px;
    padding: 15px 25px;
    display: flex;
    align-items: center;
    gap: 15px;
    border: 2px solid #b87aff;
    color: #dbb0ff;
}

/* Upload Zone */
.upload-zone {
    border: 3px dashed #b87aff;
    background: #1f1137;
    border-radius: 40px;
    padding: 40px;
    text-align: center;
    cursor: pointer;
    transition: 0.2s;
}

.upload-zone:hover {
    background: #2c1b48;
    border-color: #f0bcff;
}

.upload-zone i {
    font-size: 3.5rem;
    color: #d09eff;
    margin-bottom: 15px;
}

.upload-zone h3 {
    color: #e9cbff;
    margin-bottom: 8px;
}

.or-divider {
    display: flex;
    align-items: center;
    color: #b87aff;
    margin: 25px 0;
    font-weight: 600;
}

.or-divider::before, .or-divider::after {
    content: "";
    flex: 1;
    height: 2px;
    background: linear-gradient(90deg, transparent, #b87aff, transparent);
}

textarea {
    width: 100%;
    background: #150c22;
    border: 2px solid #b87aff;
    border-radius: 30px;
    padding: 20px;
    color: white;
    font-size: 1rem;
    resize: vertical;
    outline: none;
    margin-bottom: 20px;
}

textarea:focus {
    border-color: #f0b5ff;
    box-shadow: 0 0 30px #d18eff;
}

.abck-bar {
    display: flex;
    align-items: center;
    gap: 20px;
    background: #261942;
    border-radius: 60px;
    padding: 15px 25px;
    border: 2px solid #b87aff;
    flex-wrap: wrap;
}

.counter {
    background: #402970;
    padding: 8px 25px;
    border-radius: 40px;
    font-weight: 600;
    color: #e9cbff;
}

/* Stats */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 20px;
    margin-bottom: 25px;
}

.stat {
    background: #2f1b50;
    border-radius: 40px;
    padding: 20px;
    text-align: center;
    border: 2px solid #b87aff;
}

.stat-number {
    font-size: 2.5rem;
    font-weight: 800;
    color: #f0d2ff;
    line-height: 1.2;
}

.stat-label {
    color: #b882ff;
    font-weight: 600;
}

/* Progress */
.progress-bar {
    width: 100%;
    height: 20px;
    background: #2f1b4f;
    border-radius: 30px;
    overflow: hidden;
    margin: 20px 0 30px;
}

.progress-fill {
    height: 100%;
    width: 0%;
    background: linear-gradient(90deg, #ca80ff, #ffb7ff);
    transition: width 0.3s ease;
}

/* Results Container */
.results-container {
    background: #180c28;
    border-radius: 40px;
    padding: 20px;
    max-height: 500px;
    overflow-y: auto;
    border: 2px solid #b87aff;
    margin-bottom: 20px;
}

.result-item {
    background: #2f1b50;
    border-left: 10px solid #b87aff;
    border-radius: 30px;
    padding: 20px;
    margin-bottom: 15px;
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 10px 20px;
    border: 1px solid #e5b0ff;
}

.result-item.valid { border-left-color: #00ff88; }
.result-item.invalid { border-left-color: #ff4d4d; }
.result-item.banned { border-left-color: #ffaa00; }

.result-icon {
    font-size: 1.8rem;
    grid-row: span 3;
}

.result-detail {
    display: flex;
    flex-wrap: wrap;
    gap: 15px 25px;
    align-items: center;
}

.result-detail strong {
    color: #d2a2ff;
    min-width: 70px;
}

.result-detail span {
    color: white;
}

.empty-state {
    text-align: center;
    padding: 50px;
    color: #b27fe0;
}

.empty-state i {
    font-size: 3rem;
    margin-bottom: 15px;
}

/* Controls */
.control-bar {
    display: flex;
    gap: 15px;
    justify-content: flex-end;
}

/* Footer */
.footer {
    margin-top: 30px;
    display: flex;
    justify-content: space-between;
    color: #b27fe0;
    border-top: 2px solid #b87aff;
    padding-top: 20px;
}

/* Loading */
.loading {
    display: inline-block;
    width: 20px;
    height: 20px;
    border: 3px solid #b87aff;
    border-top-color: transparent;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}